// Re-export from main entities file for backward compatibility
export type { DocumentTemplates } from './index';
