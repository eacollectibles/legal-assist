// Re-export from main entities file for backward compatibility
export type { Bookings } from './index';
