import { MemberProvider } from '@/integrations';
import { createBrowserRouter, RouterProvider, Navigate, Outlet } from 'react-router-dom';
import { ScrollToTop } from '@/lib/scroll-to-top';
import ErrorPage from '@/integrations/errorHandlers/ErrorPage';
import HomePage from '@/components/pages/HomePage';
import AboutPage from '@/components/pages/AboutPage';
import ServicesPage from '@/components/pages/ServicesPage';
import SmallClaimsPage from '@/components/pages/SmallClaimsPage';
import LandlordTenantBoardPage from '@/components/pages/LandlordTenantBoardPage';
import HumanRightsTribunalPage from '@/components/pages/HumanRightsTribunalPage';
import TrafficTicketsPage from '@/components/pages/TrafficTicketsPage';
import BookingPage from '@/components/pages/BookingPage';

import MediationServicesPage from '@/components/pages/MediationServicesPage';
import CriminalMattersPage from '@/components/pages/CriminalMattersPage';
import BailHearingsPage from '@/components/pages/BailHearingsPage';
import NotaryPublicPage from '@/components/pages/NotaryPublicPage';
import CommissionerOfOathsPage from '@/components/pages/CommissionerOfOathsPage';
import SocialBenefitsTribunalPage from '@/components/pages/SocialBenefitsTribunalPage';
import DefamationSlanderPage from '@/components/pages/DefamationSlanderPage';
import EmploymentIssuesPage from '@/components/pages/EmploymentIssuesPage';
import ContactPage from '@/components/pages/ContactPage';
import MeetingDashboardPage from '@/components/pages/MeetingDashboardPage';
import MeetingRequestPage from '@/components/pages/MeetingRequestPage';
import AdminMeetingRequestsPage from '@/components/pages/AdminMeetingRequestsPage';
import AdminBookingsPage from '@/components/pages/AdminBookingsPage';
import ClientSignupPage from '@/components/pages/ClientSignupPage';
import ClientLoginPage from '@/components/pages/ClientLoginPage';
import ClientDashboardPage from '@/components/pages/ClientDashboardPage';
import AdminMessagesPage from '@/components/pages/AdminMessagesPage';
import AdminUserManagementPage from '@/components/pages/AdminUserManagementPage';
import AdminUserDetailPage from '@/components/pages/AdminUserDetailPage';
import GrantAdminPage from '@/components/pages/GrantAdminPage';
import ParalegalDashboardPage from '@/components/pages/ParalegalDashboardPage';
import DocumentWorkflowPage from '@/components/pages/DocumentWorkflowPage';
import PublicUploadPage from '@/components/pages/PublicUploadPage';
import UploadTokenManagementPage from '@/components/pages/UploadTokenManagementPage';
import ClientIntakePage from '@/components/pages/ClientIntakePage';
import ParalegalVsLawyerPage from '@/components/pages/ParalegalVsLawyerPage';
import WhatIsAParalegalPage from '@/components/pages/WhatIsAParalegalPage';

// SEO Landing Pages
import LondonParalegalPage from '@/components/pages/LondonParalegalPage';
import SpeedingTicketDefencePage from '@/components/pages/SpeedingTicketDefencePage';
import CarelessDrivingDefencePage from '@/components/pages/CarelessDrivingDefencePage';
import StuntDrivingDefencePage from '@/components/pages/StuntDrivingDefencePage';
import LandlordServicesPage from '@/components/pages/LandlordServicesPage';
import TenantServicesPage from '@/components/pages/TenantServicesPage';
import EvictionNonPaymentPage from '@/components/pages/EvictionNonPaymentPage';
import SmallClaimsProcessPage from '@/components/pages/SmallClaimsProcessPage';

// Layout component that includes ScrollToTop
function Layout() {
  return (
    <>
      <ScrollToTop />
      <Outlet />
    </>
  );
}

const router = createBrowserRouter([
  {
    path: "/",
    element: <Layout />,
    errorElement: <ErrorPage />,
    children: [
      {
        index: true,
        element: <HomePage />,
      },
      {
        path: "about",
        element: <AboutPage />,
      },
      {
        path: "services",
        element: <ServicesPage />,
      },
      {
        path: "services/small-claims",
        element: <SmallClaimsPage />,
      },
      {
        path: "services/landlord-tenant-board",
        element: <LandlordTenantBoardPage />,
      },
      {
        path: "services/human-rights-tribunal",
        element: <HumanRightsTribunalPage />,
      },
      {
        path: "services/traffic-tickets",
        element: <TrafficTicketsPage />,
      },

      {
        path: "services/mediation",
        element: <MediationServicesPage />,
      },
      {
        path: "services/criminal-matters",
        element: <CriminalMattersPage />,
      },
      {
        path: "services/bail-hearings",
        element: <BailHearingsPage />,
      },
      {
        path: "services/notary-public",
        element: <NotaryPublicPage />,
      },
      {
        path: "services/commissioner-of-oaths",
        element: <CommissionerOfOathsPage />,
      },
      {
        path: "services/social-benefits-tribunal",
        element: <SocialBenefitsTribunalPage />,
      },
      {
        path: "services/defamation-slander",
        element: <DefamationSlanderPage />,
      },
      {
        path: "services/employment-issues",
        element: <EmploymentIssuesPage />,
      },
      {
        path: "booking",
        element: <BookingPage />,
      },
      {
        path: "contact",
        element: <ContactPage />,
      },
      {
        path: "dashboard",
        element: <MeetingDashboardPage />,
      },
      {
        path: "meeting-request",
        element: <MeetingRequestPage />,
      },
      {
        path: "admin/meeting-requests",
        element: <AdminMeetingRequestsPage />,
      },
      {
        path: "admin/bookings",
        element: <AdminBookingsPage />,
      },
      {
        path: "admin/messages",
        element: <AdminMessagesPage />,
      },
      {
        path: "admin/users",
        element: <AdminUserManagementPage />,
      },
      {
        path: "admin/users/:userId",
        element: <AdminUserDetailPage />,
      },
      {
        path: "client-signup",
        element: <ClientSignupPage />,
      },
      {
        path: "client-login",
        element: <ClientLoginPage />,
      },
      {
        path: "client-dashboard",
        element: <ClientDashboardPage />,
      },
      {
        path: "client-intake",
        element: <ClientIntakePage />,
      },
      {
        path: "grant-admin",
        element: <GrantAdminPage />,
      },
      {
        path: "paralegal-dashboard",
        element: <ParalegalDashboardPage />,
      },
      {
        path: "document-workflow",
        element: <DocumentWorkflowPage />,
      },
      {
        path: "upload/:token",
        element: <PublicUploadPage />,
      },
      {
        path: "upload-token-management",
        element: <UploadTokenManagementPage />,
      },
      {
        path: "paralegal-vs-lawyer",
        element: <ParalegalVsLawyerPage />,
      },
      {
        path: "what-is-a-paralegal",
        element: <WhatIsAParalegalPage />,
      },
      // SEO Landing Pages
      {
        path: "london-paralegal",
        element: <LondonParalegalPage />,
      },
      {
        path: "services/speeding-ticket-defence",
        element: <SpeedingTicketDefencePage />,
      },
      {
        path: "services/careless-driving-defence",
        element: <CarelessDrivingDefencePage />,
      },
      {
        path: "services/stunt-driving-defence",
        element: <StuntDrivingDefencePage />,
      },
      {
        path: "services/landlord-services",
        element: <LandlordServicesPage />,
      },
      {
        path: "services/tenant-services",
        element: <TenantServicesPage />,
      },
      {
        path: "services/eviction-non-payment",
        element: <EvictionNonPaymentPage />,
      },
      {
        path: "services/small-claims-process",
        element: <SmallClaimsProcessPage />,
      },
      {
        path: "*",
        element: <Navigate to="/" replace />,
      },
    ],
  },
], {
  basename: import.meta.env.BASE_NAME,
});

export default function AppRouter() {
  return (
    <MemberProvider>
      <RouterProvider router={router} />
    </MemberProvider>
  );
}
