import { items } from "@wix/data";

export type WixDataItem = items.WixDataItem;
export type WixDataQueryResult = items.WixDataResult;
