EA COLLECTIBLES — Matrixify Bulk Import (v3 — final)

Fixes from v1 / v2
------------------
1) Hamilton title was getting split by an unquoted comma; the
   row's columns shifted, putting the wrong value into Published
   and skipping the import. Title is now plain "Trading Cards
   Hamilton" (no comma).
2) Every cell is now fully quoted (RFC 4180 strict) so no future
   comma in any field can break the layout.
3) Removed Vendor + Tags columns (Pages don't have those — they
   were the "unknown columns" warning in v1).
4) SEO Title and Meta Description use Matrixify's correct
   Pages-metafield column names.

What to do
----------
Batch-1 already has 8 pages live (from your earlier v1 run, minus
Hamilton). To finish batch-1:

  - In Matrixify, upload shopify-pages-batch-1-gta-priority-v3.csv
  - Set import mode to "Update existing" (so the 8 already-live
    pages get their SEO title + meta description filled in).
  - The 9th row (Hamilton) will be created fresh.

For batches 2 through 5: run them as fresh "New" imports.

Run a Dry Run on each batch before the real import — should show
0 errors, 0 warnings, 0 unknown columns.

Phased rollout (one batch per week)
-----------------------------------
Week 1: shopify-pages-batch-1-gta-priority-v3.csv         (9)
Week 2: shopify-pages-batch-2-rest-of-gta-niagara-v3.csv  (9)
Week 3: shopify-pages-batch-3-kw-western-v3.csv           (9)
Week 4: shopify-pages-batch-4-near-london-eastern-v3.csv  (9)
Week 5: shopify-pages-batch-5-cottage-northern-v3.csv     (7)
