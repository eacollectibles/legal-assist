EA COLLECTIBLES — Rich Product Schema (JSON-LD)

What's in this zip
------------------
  snippets/product-schema.liquid
        207-line drop-in snippet that emits a comprehensive Product
        JSON-LD schema for every product page. Adds aggregateRating
        (when reviews data is available), AggregateOffer for
        multi-variant products, MerchantReturnPolicy, OfferShippingDetails,
        ItemCondition, GTIN/MPN, multi-image, brand, and category.
        All conditional — fields with no data are omitted cleanly.

INSTALL — two steps
-------------------
1) Drop the snippet into your theme.

   Shopify CLI:
     cd <your local theme folder>
     copy snippets\product-schema.liquid into your theme's snippets/
     shopify theme push --only "snippets/product-schema.liquid"

   OR Shopify admin:
     Online Store -> Themes -> Edit code -> Snippets -> Add a new snippet
     Name: product-schema
     Paste the contents of the .liquid file from this zip.
     Save.

2) Replace the existing Product JSON-LD in main-product.liquid with the
   new snippet.

   In your theme:
     sections/main-product.liquid (open it in the code editor)

   Find the existing JSON-LD block. It looks something like:

     <script type="application/ld+json">
       {{ product | structured_data }}
     </script>

   ...or a hand-written block beginning with:

     <script type="application/ld+json">
       {
         "@context": "https://schema.org/",
         "@type": "Product",
         ...

   REPLACE that entire <script>...</script> block with this single line:

     {% render 'product-schema', product: product %}

   Save the file.

Important: don't keep both blocks. Google flags duplicate Product
schema. Replace, don't supplement.

Verify it worked
----------------
1) Open any product page on your live site.
2) Right-click -> View Page Source.
3) Search (Ctrl+F) for "schema.org/Product". You should see the new
   block with all the fields populated.
4) Test with Google's Rich Results Test:
     https://search.google.com/test/rich-results
   Enter the product URL. Should show "Product snippets" eligible
   with no errors.
5) Within 1-3 weeks, your products will start appearing as rich
   results in Google Search and Google Shopping with stars (if
   reviews configured), price, availability, etc.

Reviews data — optional but high-impact
---------------------------------------
The aggregateRating block in the schema only emits if at least ONE
of these metafields exists on the product:

   product.metafields.reviews.rating         (or rating_value)
   product.metafields.reviews.rating_count   (or review_count)
   product.metafields.loox.avg_rating
   product.metafields.loox.num_reviews

Most reviews apps (Loox, Judge.me, Yotpo, Stamped) write to one of
these. Once you install a reviews app and it populates the metafields,
star ratings start appearing in Google Search results — which
typically doubles or triples your click-through rate from organic.

If you don't have a reviews app yet, the schema just omits the
rating block — no errors, no warnings.

Customizing for your store
--------------------------
The snippet hardcodes a few EA-Collectibles-specific values:
  - Default item condition: NewCondition (with Used/Refurbished
    overrides if the product is tagged "used", "preowned", "open-box").
    Adjust the tag list inside the snippet if you use different tags.
  - Return policy: 14 days, free returns, by mail, Canada only.
    Edit hasMerchantReturnPolicy in the snippet to match your actual
    policy.
  - Shipping: $0, 1-3 day handling + 1-5 day transit, Canada.
    Edit shippingDetails to match your real fulfillment times.

These four spots are clearly labelled in the snippet — find them by
searching for "EDIT THIS" or just look at the conditions/return/shipping
blocks.
