EA COLLECTIBLES — Matrixify Bulk Import (v2 — corrected)

What changed from v1
--------------------
1) Removed the columns Matrixify warned were unknown for Pages
   (Vendor, Tags). They were silently ignored before — these
   are not real Page fields in Shopify.

2) Replaced "SEO Title" and "SEO Description" with their
   correct Matrixify metafield column names:
       Metafield: global.title_tag [single_line_text_field]
       Metafield: global.description_tag [multi_line_text_field]
   This means the SEO Title + Meta Description will now actually
   land on each page (in v1 they didn't because the columns
   weren't recognized).

3) Hamilton's Title had a comma in it (only failure in batch-1).
   Cleaned to remove the comma so the CSV parses cleanly.

How to use
----------
1) IMPORTANT: re-run batch-1 with this v2 file. Set the import
   mode to "Update existing" so Matrixify updates the 8 pages
   that already exist (filling in their SEO fields) and creates
   the missing Hamilton page. If you instead want to wipe and
   re-create, delete those 8 pages first in Online Store -> Pages.

2) For batches 2-5, just run them as fresh imports (mode "New").

3) Run a Dry Run first on each batch to confirm 0 errors / 0
   warnings before the real run.

Phased rollout (one batch per week)
-----------------------------------
Week 1: shopify-pages-batch-1-gta-priority-v2.csv          (9 cities)
Week 2: shopify-pages-batch-2-rest-of-gta-niagara-v2.csv  (9 cities)
Week 3: shopify-pages-batch-3-kw-western-v2.csv            (9 cities)
Week 4: shopify-pages-batch-4-near-london-eastern-v2.csv  (9 cities)
Week 5: shopify-pages-batch-5-cottage-northern-v2.csv     (7 cities)
