EA COLLECTIBLES — SEO CHANGES ONLY
==========================================

Files in this zip (ONLY the things I changed or created — not the full
theme; everything else in your live theme is untouched).

  sections/
    page-service-area.liquid
        Replaces your existing sections/page-service-area.liquid.
        New optional settings: tcg_focus, h1_override, local_intro,
        local_landmark, area_served_region, local_testimonial_quote,
        local_testimonial_attribution. All optional — your existing
        5 city pages keep working unchanged.

  templates/page.<city>.json (43 NEW files)
        One per new Ontario city, ordered roughly by population /
        proximity. They use the section above with per-city settings
        (drive time, distance, route, custom H1, local intro).
        Existing page.sarnia.json / page.st-thomas.json / etc. are
        not in this zip and stay as-is on your theme.

  shopify-pages-bulk-import.csv
        43-row CSV in the Matrixify "Pages" sheet format. Use this
        with the Matrixify app (or any Shopify Pages bulk-import tool)
        to create the 43 corresponding Shopify Page entries instead
        of clicking 43 times in admin. Columns: Handle, Title, Body
        HTML, Vendor, Tags, Template Suffix, Published, SEO Title,
        SEO Description.

INSTALL (Shopify CLI option — fastest)
--------------------------------------
  1) cd into your local theme folder.
  2) Copy each file from this zip to the same path in your theme.
  3) shopify theme push (or `shopify theme dev` to preview first).

INSTALL (no CLI option)
-----------------------
  1) In Shopify admin: Online Store -> Themes -> ... -> Edit code
     on your unpublished "Copy of Dawn" theme.
  2) For sections/page-service-area.liquid: open the file in the
     editor, paste in the new contents, click Save.
  3) For each templates/page.<city>.json file: in the editor, click
     "Add a new template", choose Page, JSON, name the suffix
     "<city>" (e.g. "toronto"), and paste the file contents in.

THEN — create the Shopify Pages
-------------------------------
  Easy path: install the Matrixify app, go to Import, upload
  shopify-pages-bulk-import.csv, run. Done.

  Manual path: Online Store -> Pages -> Add page. For each row in
  the CSV: Title -> Title, URL -> Handle, Theme template -> the
  matching custom template (e.g. "toronto"), then click "Edit
  website SEO" and paste in the SEO Title and Meta description.

SEO ROLLOUT PACE — IMPORTANT
----------------------------
Don't publish all 43 pages on day 1. Push 5-10 per week to avoid
Google's doorway-page detection treating a sudden flood as spam.
Suggested order:
  Week 1: Toronto, Mississauga, Brampton, Hamilton, Kitchener
  Week 2: Markham, Vaughan, Waterloo, Cambridge, Guelph
  Week 3: Oakville, Burlington, Brantford, Niagara Falls, St Catharines
  Week 4: Richmond Hill, Markham, Aylmer, Ingersoll, Strathroy
  Week 5: Oshawa, Whitby, Ajax, Pickering, Tillsonburg
  Week 6: Owen Sound, Goderich, Milton, Newmarket, Welland
  Week 7: Fort Erie, Barrie, Orillia, Collingwood, Cobourg
  Week 8: Peterborough, Belleville, Kingston, Sudbury, North Bay
  Week 9: Ottawa, Cornwall, Sault Ste Marie, Thunder Bay
