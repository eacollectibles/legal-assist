EA COLLECTIBLES — Matrixify Bulk Import (5 batches, free-tier-friendly)

Matrixify's free tier caps each import at 10 rows. The full 43-row
CSV gets cut off. These 5 smaller files keep every batch under the
limit and align with an SEO-safe phased rollout.

How to use
----------
1) Make sure the theme template files (the page-service-area.liquid
   + 43 page.<city>.json files from the previous zip) are installed
   in your Shopify theme first. Pages without a matching template
   will 404.

2) In Shopify admin: Apps -> Matrixify -> Import.

3) Upload ONE batch CSV. Start with batch-1.

4) Run a Dry Run first. Then run for real.

5) Verify a couple of new pages: Online Store -> Pages -> click one
   and "View page".

6) Repeat with the next batch.

Suggested phased rollout (one batch per week, safest for SEO)
-------------------------------------------------------------
Week 1: shopify-pages-batch-1-gta-priority.csv          (9 cities)
Week 2: shopify-pages-batch-2-rest-of-gta-niagara.csv  (9 cities)
Week 3: shopify-pages-batch-3-kw-western.csv            (9 cities)
Week 4: shopify-pages-batch-4-near-london-eastern.csv  (9 cities)
Week 5: shopify-pages-batch-5-cottage-northern.csv     (7 cities)

You can also run all 5 back-to-back if you want everything live now.
Doorway-page risk is mitigated by the unique-content boosters in
your template (custom H1, local intro, local landmark, varied TCG
focus per city) but slow rollouts are always safer.

Columns in each file: Handle, Title, Body HTML, Vendor, Tags,
Template Suffix, Published, SEO Title, SEO Description.
