EA COLLECTIBLES — Metafield-driven SEO pages (v4)

Why v4
======
Shopify regenerates JSON page templates on certain admin actions and
strips section.settings. v4 moves all per-city data onto Shopify Page
metafields (namespace "eac"), which Shopify never strips.

Files in this zip
-----------------
  sections/page-service-area.liquid
      Updated section template that reads from page.metafields.eac.*
      first, with section.settings.* as a fallback so your existing 5
      city pages (Sarnia, St Thomas, etc.) keep working unchanged.

  shopify-pages-batch-{1..5}-...-v4.csv
      Matrixify CSV files. Each row sets the page's metafields:
        eac.city_name
        eac.region_name
        eac.drive_time
        eac.distance
        eac.route
        eac.tcg_focus
        eac.h1_override
        eac.local_intro
        eac.local_landmark
        eac.area_served_region
      Plus the page's SEO Title and Meta Description.
      9 rows per batch (under Matrixify free-tier 10/job cap).

Apply order
-----------
1) Push the new section template:

   cd "C:\Users\jeanf\Downloads\eacollectibles-v4-metafields"
   shopify theme push --store=ke40sv-my.myshopify.com --theme=175952462146 --only "sections/page-service-area.liquid" --allow-live --nodelete

2) For batch-1 (the 9 pages already imported), run Matrixify in
   "Update existing" mode with shopify-pages-batch-1-gta-priority-v4.csv.
   This sets the metafields on each existing page without
   creating duplicates. The pages will start rendering correctly
   within 60 seconds.

3) For batches 2-5, run as fresh "New" imports. Each Page row in
   the CSV is created with its metafields already populated.

Verify
------
After step 2, hard-refresh https://eacollectibles.com/pages/pokemon-cards-toronto.
The H1 should be "Toronto's Trusted Pokemon & Trading Card Source".
The drive-time box should show "Only 2 hours from Toronto / 190 km via Highway 401".

If still empty: confirm in admin (Online Store -> Pages -> Toronto -> scroll to "Metafields" near the bottom) that eac.city_name etc. are populated.
